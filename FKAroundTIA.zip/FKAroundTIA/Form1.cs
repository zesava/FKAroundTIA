﻿using Siemens.Engineering;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Win32;

namespace FKAroundTIA
{
    public partial class Form1 : Form
    {
        static Form1()
        {
            AppDomain.CurrentDomain.AssemblyResolve += ResolveTiaAssembly;
        }

        public Form1()
        {
            InitializeComponent();
        }

        // =========================
        // 🔥 Assembly Resolver (correct V21)
        // =========================
        private static Assembly ResolveTiaAssembly(object sender, ResolveEventArgs args)
        {
            string name = new AssemblyName(args.Name).Name;

            using (var key = Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Siemens\Automation\Openness\21.0\PublicAPI\21.0.0.0\net48"))
            {
                if (key == null)
                    return null;

                foreach (var valueName in key.GetValueNames())
                {
                    if (!valueName.StartsWith(name))
                        continue;

                    var path = key.GetValue(valueName) as string;

                    if (!string.IsNullOrEmpty(path) && File.Exists(path))
                    {
                        return Assembly.LoadFrom(path);
                    }
                }
            }

            return null;
        }

        // =========================
        // 🔥 Test
        // =========================
        private void btnCreateProject_Click(object sender, EventArgs e)
        {
            using (TiaPortal tiaPortal = new TiaPortal(TiaPortalMode.WithUserInterface))
            {
                MessageBox.Show("TIA Openness loaded correctly via registry mapping!");
            }
        }
    }
}